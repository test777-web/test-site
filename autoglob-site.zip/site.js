// AutoGlob shared site script

// ---- Theme toggle (dark/light) ----
(function () {
  const root = document.documentElement;
  const saved = localStorage.getItem('autoglob-theme');
  if (saved === 'light') root.setAttribute('data-theme', 'light');

  document.addEventListener('DOMContentLoaded', function () {
    const btn = document.getElementById('themeToggle');
    if (!btn) return;

    btn.addEventListener('click', function () {
      const isLight = root.getAttribute('data-theme') === 'light';
      if (isLight) {
        root.removeAttribute('data-theme');
        localStorage.setItem('autoglob-theme', 'dark');
      } else {
        root.setAttribute('data-theme', 'light');
        localStorage.setItem('autoglob-theme', 'light');
      }
    });
  });
})();

// ---- Modals (Newsletter / Sign in) ----
function openModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.add('open');
}
function closeModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.remove('open');
}

document.addEventListener('DOMContentLoaded', function () {
  // Newsletter form submit (front-end only, no backend wired yet)
  const newsletterForm = document.getElementById('newsletterForm');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const msg = document.getElementById('newsletterMsg');
      if (msg) msg.classList.add('show');
      newsletterForm.reset();
    });
  }

  // Close modal on background click
  document.querySelectorAll('.modal-overlay').forEach(function (overlay) {
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) overlay.classList.remove('open');
    });
  });

  // ---- Search toggle + live filter (index page only) ----
  const searchToggle = document.getElementById('searchToggle');
  const searchBox = document.getElementById('searchBox');
  const searchInput = document.getElementById('searchInput');
  if (searchToggle && searchBox) {
    searchToggle.addEventListener('click', function () {
      searchBox.classList.toggle('open');
      if (searchBox.classList.contains('open') && searchInput) searchInput.focus();
    });
  }
  if (searchInput) {
    searchInput.addEventListener('input', function () {
      const q = searchInput.value.trim().toLowerCase();
      document.querySelectorAll('.article-card').forEach(function (card) {
        const title = card.querySelector('h4') ? card.querySelector('h4').textContent.toLowerCase() : '';
        card.classList.toggle('hidden', q.length > 0 && !title.includes(q));
      });
    });
  }

  // ---- Category filter via main nav (index page only) ----
  const navLinks = document.querySelectorAll('nav.main-nav a[data-filter]');
  navLinks.forEach(function (link) {
    link.addEventListener('click', function (e) {
      const filter = link.getAttribute('data-filter');
      const grid = document.querySelector('.articles-grid');
      if (!grid) return; // not on index page, let link navigate normally
      e.preventDefault();
      navLinks.forEach(function (l) { l.classList.remove('active'); });
      link.classList.add('active');
      document.querySelectorAll('.article-card').forEach(function (card) {
        const cat = card.getAttribute('data-category');
        card.classList.toggle('hidden', filter !== 'all' && cat !== filter);
      });
      document.getElementById('recent-articles').scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });
});
